package PECOCMEPFileTrimmer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.univocity.parsers.common.ParsingContext;
import com.univocity.parsers.common.processor.RowListProcessor;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

public class CMEPTrimmer {
	static class MeterSearch extends RowListProcessor {
		private final String sMatch;
		private final String cMatch;
		private int iMatch = -1;

		public MeterSearch(String cMatch, String sMatch) {
			this.cMatch = cMatch;
			this.sMatch = sMatch.toLowerCase();
		}

		public MeterSearch(int cMatch, String sMatch) {
			this(sMatch, null);
			iMatch = cMatch;
		}

		@Override
		public void rowProcessed(String[] row, ParsingContext context) {
			if (iMatch == -1) {
				iMatch = context.indexOf(cMatch);
			}

			String value = row[iMatch];
			if (value != null && value.toLowerCase().contains(sMatch)) {
				super.rowProcessed(row, context);
			}

		}
	}


	public void main(String MeterPath, String CMEPProd, String CMEPTrimmed) throws IOException {
		
		File fileMeterNumbers = new File(MeterPath);
		List<String> lstMeterNumbers = loadMeterNumberList(fileMeterNumbers);
		

		long start = System.currentTimeMillis();
		System.out.println("Start time ........ : " + start);
		
		CsvWriter writer = new CsvWriter(new FileWriter(CMEPTrimmed), new CsvWriterSettings());

		int meterCount = lstMeterNumbers.size();
		JOptionPane.showMessageDialog(null,
				"Meters to Trim: " + (meterCount - 1) + "\nEstimated time: " + ((meterCount - 1) * 1) / 600 + " minutes",
				"PECO CMEP Trimmer Estimates ", JOptionPane.INFORMATION_MESSAGE);

		FileReader fileReader = new FileReader(new File(CMEPProd));
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			String strMeterNumber = line.split(",")[5];
			if (null != strMeterNumber && lstMeterNumbers.contains(strMeterNumber)) {
				System.out.println("Writing the meter info for  MeterNumber#: " + strMeterNumber);
				writer.writeRow(line);
			}
		}
		fileReader.close();
		writer.close();
		System.out.println("End time ........ : " + System.currentTimeMillis());
		System.out.println("Total Time taken ---------- : " + (System.currentTimeMillis() - start)/60000 + " min");
		System.out.println("Completed");
		JOptionPane.showMessageDialog(null, "CMEP File trim is completed ", "PECO CMEP Trimmer Status",
				JOptionPane.INFORMATION_MESSAGE);
		
	}
	
	/**
	 * Method to read the Meter Number List file and load lines to ArrayList.
	 * eg: List<H016999422>
	 * 
	 * @param fileMeterNumbers
	 * @return
	 */
	private List<String> loadMeterNumberList(File fileMeterNumbers) throws IOException{
		List<String> meterNumberLst = new ArrayList<String>();
		FileReader fileReader = new FileReader(fileMeterNumbers);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			meterNumberLst.add(line);
		}
		fileReader.close();

		return meterNumberLst;
	}

};