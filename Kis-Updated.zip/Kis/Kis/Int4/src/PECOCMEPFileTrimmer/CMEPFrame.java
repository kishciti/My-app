package PECOCMEPFileTrimmer;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.JSeparator;
import javax.swing.JProgressBar;
import java.awt.Toolkit;
import java.awt.Container;

public class CMEPFrame extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JFrame frmCmep;
	private JTextField txtMeterPath;
	private JTextField txtCMEPProd;
	private JTextField txtCMEPTrimmed;
	private JTextField txtPecoCmepFile;

	public void initialize() {
		frmCmep = new JFrame();
		frmCmep.setTitle("PECO CMEP File Trimer");
//		frmCmep.setIconImage(Toolkit.getDefaultToolkit()
//				.getImage(CMEPFrame.class.getResource("/com/sun/javafx/scene/web/skin/Cut_16x16_JFX.png")));
		frmCmep.getContentPane().setForeground(Color.BLACK);
		frmCmep.setBounds(100, 100, 635, 386);
		frmCmep.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCmep.getContentPane().setLayout(null);

		JLabel lblCMEPProdFilesPath = new JLabel("CMEP Production Files path:");
		lblCMEPProdFilesPath.setForeground(Color.BLACK);
		lblCMEPProdFilesPath.setFont(new Font("Calibri", Font.BOLD, 14));
		lblCMEPProdFilesPath.setBackground(Color.CYAN);
		lblCMEPProdFilesPath.setBounds(30, 83, 182, 18);
		frmCmep.getContentPane().add(lblCMEPProdFilesPath);

		JLabel lblPECOTestMeters = new JLabel("PECO Test Meters Path:");
		lblPECOTestMeters.setFont(new Font("Calibri", Font.BOLD, 14));
		lblPECOTestMeters.setForeground(Color.BLACK);
		lblPECOTestMeters.setBackground(new Color(0, 255, 255));
		lblPECOTestMeters.setBounds(30, 134, 182, 18);
		frmCmep.getContentPane().add(lblPECOTestMeters);

		JLabel lblCMEPTrimmedFilePath = new JLabel("CMEP Trimmed File Path:");
		lblCMEPTrimmedFilePath.setForeground(Color.BLACK);
		lblCMEPTrimmedFilePath.setFont(new Font("Calibri", Font.BOLD, 14));
		lblCMEPTrimmedFilePath.setBackground(Color.CYAN);
		lblCMEPTrimmedFilePath.setBounds(30, 188, 182, 18);
		frmCmep.getContentPane().add(lblCMEPTrimmedFilePath);

		txtCMEPProd = new JTextField();
		txtCMEPProd.setColumns(10);
		txtCMEPProd.setBounds(222, 83, 344, 20);
		frmCmep.getContentPane().add(txtCMEPProd);

		txtMeterPath = new JTextField();
		txtMeterPath.setBounds(222, 132, 344, 20);
		frmCmep.getContentPane().add(txtMeterPath);
		txtMeterPath.setColumns(10);

		txtCMEPTrimmed = new JTextField();
		txtCMEPTrimmed.setColumns(10);
		txtCMEPTrimmed.setBounds(222, 186, 344, 20);
		frmCmep.getContentPane().add(txtCMEPTrimmed);

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Calibri", Font.BOLD, 14));

		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String MeterPath = txtMeterPath.getText();
				String CMEPProd = txtCMEPProd.getText();
				String CMEPTrimmed = txtCMEPTrimmed.getText()+"Trimmed data.csv";
				CMEPTrimmer ct = new CMEPTrimmer();
				try {
					ct.main(MeterPath, CMEPProd, CMEPTrimmed);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}

		});

		btnSubmit.setBounds(76, 256, 112, 46);
		frmCmep.getContentPane().add(btnSubmit);

		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtMeterPath.setText(null);
				txtCMEPProd.setText(null);
				txtCMEPTrimmed.setText(null);
			}
		});
		btnReset.setFont(new Font("Calibri", Font.BOLD, 14));
		btnReset.setBounds(263, 256, 112, 46);
		frmCmep.getContentPane().add(btnReset);

		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Calibri", Font.BOLD, 14));
		btnExit.setBounds(454, 256, 112, 46);
		frmCmep.getContentPane().add(btnExit);

		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(0, 236, 619, 2);
		frmCmep.getContentPane().add(separator_3);

		JSeparator separator = new JSeparator();
		separator.setBounds(0, 60, 619, 2);
		frmCmep.getContentPane().add(separator);

		/*
		 * JProgressBar progressBar = new JProgressBar(); progressBar.setBackground(new
		 * Color(204, 255, 255)); progressBar.setBounds(156, 322, 365, 14);
		 * frmCmep.getContentPane().add(progressBar);
		 * 
		 * progressBar.setValue(1); progressBar.setStringPainted(true);
		 */
		/*
		 * frmCmep.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); Container content =
		 * frmCmep.getContentPane(); progressBar.setValue(25);
		 * progressBar.setStringPainted(true); Border border =
		 * BorderFactory.createTitledBorder("Reading...");
		 * progressBar.setBorder(border); content.add(progressBar, BorderLayout.NORTH);
		 * frmCmep.setSize(300, 100); frmCmep.setVisible(true);
		 */

		txtPecoCmepFile = new JTextField();
		txtPecoCmepFile.setForeground(Color.WHITE);
		txtPecoCmepFile.setFont(new Font("Calibri", Font.BOLD, 20));
		txtPecoCmepFile.setBackground(new Color(0, 0, 102));
		txtPecoCmepFile.setText("PECO CMEP File Trimmer");
		txtPecoCmepFile.setHorizontalAlignment(SwingConstants.CENTER);
		txtPecoCmepFile.setBounds(0, 0, 619, 30);
		frmCmep.getContentPane().add(txtPecoCmepFile);
		txtPecoCmepFile.setColumns(10);
		frmCmep.setVisible(true);
	}

	public static void main(String[] args) {
		CMEPFrame fr = new CMEPFrame();
		fr.initialize();
		// JProgressBar progressBar = new JProgressBar();
		// progressBar.setValue(100);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String MeterPath = txtMeterPath.getText();
		String CMEPProd = txtCMEPProd.getText();
		String CMEPTrimmed = txtCMEPTrimmed.getText();
		CMEPTrimmer ct = new CMEPTrimmer();
		try {
			ct.main(MeterPath, CMEPProd, CMEPTrimmed);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

};