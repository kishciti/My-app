package PECOCMEPFileTrimmer;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;


public class CMEPTrimmer {
	
//	private static DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//	private static DocumentBuilder dBuilder = null;
	
	private static SAXBuilder saxBuilder = null;
	static {
		try {
			saxBuilder = new SAXBuilder();
		} catch (Exception e) {
			System.out.println("Exception in creating Document Builder : " + e);
			e.printStackTrace();
		}
	}

	public void main(String MeterPath, String CMEPProd, String CMEPTrimmed) throws Exception {
		
		File fileMeterNumbers = new File(MeterPath);
		List<String> lstMeterNumbers = loadMeterNumberList(fileMeterNumbers);

		long start = System.currentTimeMillis();
		System.out.println("Start time ........ : " + start);
		File folder = new File(CMEPProd);
		File[] listOfFiles = folder.listFiles();
		int intRecoundCount = 1;
		Document docInputFile = null;
		Document docOutputFile = null;
		Element docOutputElement = null;
		for(int i = 0; i < listOfFiles.length; i++){
			String filename = listOfFiles[i].getName();
			if(filename.endsWith(".xml")||filename.endsWith(".XML"))
			{
				System.out.println("Reading File " + filename + " :");
				docInputFile = saxBuilder.build(new File(CMEPProd + "\\" + filename));
				Element docInputEle = docInputFile.getRootElement();
				List<Element> ndlMeterData = docInputEle.getChildren();
				int inMeterLength = ndlMeterData.size();
				Element eleMeterData = null;
				
				for (int a = 0; a < inMeterLength; a++) {
					eleMeterData = ndlMeterData.get(a);
					if(!eleMeterData.getName().equalsIgnoreCase("MeterData")) {
						continue;
					}

					if((i == 0 && null == docOutputFile) || intRecoundCount == 6) {
						Element eleSSN = new Element("SSNExportDocument");
						docOutputFile = new Document(eleSSN);
						docOutputElement = docOutputFile.getRootElement();
						copyAttributes(docOutputElement, docInputEle);
						intRecoundCount = 1;
					}

					if(lstMeterNumbers.contains(eleMeterData.getAttributeValue("MeterName"))) {
						Element elementMeterData = eleMeterData.clone();
						docOutputElement.addContent(elementMeterData);
						if(intRecoundCount == 5) {
							writeDocumentToFile(CMEPTrimmed + "_" + System.currentTimeMillis() + ".xml", docOutputFile);
						}
						intRecoundCount++;
					}
				}				
			}
		}
		
		if (intRecoundCount < 5) {
			writeDocumentToFile(CMEPTrimmed + "_" + System.currentTimeMillis() + ".xml", docOutputFile);
		}
		
		System.out.println("End time ........ : " + System.currentTimeMillis());
		System.out.println("Total Time taken ---------- : " + (System.currentTimeMillis() - start)/60000 + " min");
		System.out.println("Completed");
		JOptionPane.showMessageDialog(null, "CMEP File trim is completed ", "PECO CMEP Trimmer Status",
				JOptionPane.INFORMATION_MESSAGE);
		
	}
	
	/**
	 * Method to read the Meter Number List file and load lines to ArrayList.
	 * eg: List<H016999422>
	 * 
	 * @param fileMeterNumbers
	 * @return
	 */
	private List<String> loadMeterNumberList(File fileMeterNumbers) throws IOException{
		List<String> meterNumberLst = new ArrayList<String>();
		FileReader fileReader = new FileReader(fileMeterNumbers);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			meterNumberLst.add(line);
		}
		fileReader.close();

		return meterNumberLst;
	}
	
	private void writeDocumentToFile(String outPutFile, Document inputDocument) throws Exception{

		XMLOutputter xmlOutput = new XMLOutputter();
        xmlOutput.setFormat(Format.getPrettyFormat());
        
        FileOutputStream outputStream = new FileOutputStream(new File(outPutFile));
        xmlOutput.output(inputDocument, outputStream); 

	}

	/**
	 * This method is for setting the attribute of an element
	 * 
	 * @param objElement
	 *            Element where this attribute should be set
	 * @param attributeName
	 *            Name of the attribute
	 * @param attributeValue
	 *            Value of the attribute
	 */
	public static void setAttribute(Element objElement, String attributeName, String attributeValue) {
		objElement.setAttribute(attributeName, attributeValue);
	}

	/**
	 * This method will copy all the attribute from one node to other node.
	 * 
	 * @param toEle
	 *            toEle
	 * @param fromEle
	 *            fromEle
	 * 
	 */
	public static void copyAttributes(Element toEle, Element fromEle) {
		List<Attribute> fromAttrs = fromEle.getAttributes();

		if (fromAttrs != null) {
			int fromAttrbMapLength = fromAttrs.size();

			for (int i = 0; i < fromAttrbMapLength; i++) {
				Attribute attrbNode = fromAttrs.get(i);

				if ((attrbNode == null)) {
					continue;
				}
				
				toEle.setNamespace(fromEle.getNamespace());

				String attrbName = attrbNode.getName();
				String attrbVal = attrbNode.getValue();

				String toAttrbVal = toEle.getAttributeValue(attrbName);

				if (null == toAttrbVal || toAttrbVal.length() == 0) {
					setAttribute(toEle, attrbName, attrbVal);
				}
			}
		}
	}

};