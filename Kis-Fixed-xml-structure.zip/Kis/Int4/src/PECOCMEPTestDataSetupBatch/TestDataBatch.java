package PECOCMEPTestDataSetupBatch;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Toolkit;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.univocity.parsers.common.*;
import com.univocity.parsers.common.processor.*;
import com.univocity.parsers.csv.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;

import javax.swing.SwingConstants;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestDataBatch extends JFrame implements ActionListener {
	JFrame frmPecoRniTest;
	JTextField txtfCmepFileProd, txtfTestdataInputSheet, txtfOutputFiles;
	JButton btnUpdate, btnClear, btnExit;
	JLabel txtCmpFilePath, txtTestDataBatch1SheetPath, txtTestDataSheetPath;
	private JLabel lblNewLabel;

	static class CsvSearch extends RowListProcessor {
		private final String stringToMatch;
		private final String columnToMatch;
		private int indexToMatch = -1;

		public CsvSearch(String columnToMatch, String stringToMatch) {
			this.columnToMatch = columnToMatch;
			this.stringToMatch = stringToMatch.toLowerCase();
		}

		public CsvSearch(int columnToMatch, String stringToMatch) {
			this(stringToMatch, null);
			indexToMatch = columnToMatch;
		}

		@Override
		public void rowProcessed(String[] row, ParsingContext context) {
			if (indexToMatch == -1) {
				indexToMatch = context.indexOf(columnToMatch);
			}

			String value = row[indexToMatch];
			if (value != null && value.toLowerCase().contains(stringToMatch)) {
				super.rowProcessed(row, context);
			}
			// else skip the row.
		}
	}

	public static void main(String[] args) throws IOException {
		TestDataBatch td = new TestDataBatch();
		td.frmPecoRniTest.setVisible(true);
	}

	/*** Initialize the contents of the frame ***/
	TestDataBatch() {
		frmPecoRniTest = new JFrame("PECO RNI Test data Setup tool");
		frmPecoRniTest.setBackground(new Color(240, 240, 240));
		frmPecoRniTest.setIconImage(Toolkit.getDefaultToolkit().getImage(TestDataBatch.class
				.getResource("/com/sun/javafx/scene/control/skin/modena/HTMLEditor-Numbered-Black-rtl.png")));
		frmPecoRniTest.setBounds(100, 100, 600, 400);
		frmPecoRniTest.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPecoRniTest.getContentPane().setLayout(null);

		txtCmpFilePath = new JLabel();
		txtCmpFilePath.setBounds(10, 63, 164, 20);
		txtCmpFilePath.setForeground(new Color(0, 0, 0));
		txtCmpFilePath.setText("CMEP Production File Path");
		frmPecoRniTest.getContentPane().add(txtCmpFilePath);

		txtfCmepFileProd = new JTextField();
		txtfCmepFileProd.setBounds(186, 63, 345, 20);
		frmPecoRniTest.getContentPane().add(txtfCmepFileProd);
		txtfCmepFileProd.setColumns(10);

		txtTestDataBatch1SheetPath = new JLabel();
		txtTestDataBatch1SheetPath.setBounds(10, 127, 164, 20);
		txtTestDataBatch1SheetPath.setText("Output CMEP Test Files Path");
		frmPecoRniTest.getContentPane().add(txtTestDataBatch1SheetPath);

		txtfOutputFiles = new JTextField();
		txtfOutputFiles.setBounds(186, 127, 345, 20);
		txtfOutputFiles.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfOutputFiles);

		txtTestDataSheetPath = new JLabel();
		txtTestDataSheetPath.setBounds(10, 95, 164, 20);
		txtTestDataSheetPath.setText("Input Test Data Sheet Path");
		frmPecoRniTest.getContentPane().add(txtTestDataSheetPath);

		txtfTestdataInputSheet = new JTextField();
		txtfTestdataInputSheet.setBounds(186, 95, 345, 20);
		txtfTestdataInputSheet.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfTestdataInputSheet);

		btnUpdate = new JButton("Submit");
		btnUpdate.setBounds(10, 236, 142, 45);
		frmPecoRniTest.getContentPane().add(btnUpdate);

		btnClear = new JButton("Clear");
		btnClear.setBounds(204, 236, 142, 45);
		frmPecoRniTest.getContentPane().add(btnClear);

		btnExit = new JButton("Exit");
		btnExit.setBounds(409, 236, 142, 45);
		frmPecoRniTest.getContentPane().add(btnExit);

		lblNewLabel = new JLabel("PECO CMEP File Test data setup - Interval Status Code");
		lblNewLabel.setBounds(0, 0, 584, 30);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBackground(Color.ORANGE);
		frmPecoRniTest.getContentPane().add(lblNewLabel);
		btnUpdate.addActionListener(this);
		btnClear.addActionListener(this);
		btnExit.addActionListener(this);

	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == btnUpdate) {
			try {
				String stxtTestdataInputSheet = txtfTestdataInputSheet.getText();
				InputStream file;
				file = new FileInputStream(stxtTestdataInputSheet);
				XSSFWorkbook workbook = new XSSFWorkbook(file);
				XSSFSheet sheet = workbook.getSheetAt(0);

				int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();

				for (int i = 1; i < rowCount + 1; i++) {
					Row row = sheet.getRow(i);
					int j = 0;
					// for (int j = 0; j < row.getLastCellNum(); j++) {

					DataFormatter formatter = new DataFormatter();
					String itxtTestCaseNum = formatter.formatCellValue(row.getCell(j));
					String itxtTestConfigNum = formatter.formatCellValue(row.getCell(j + 1));
					String stxtfMeterNumber = row.getCell(j + 3).getStringCellValue();
					String itxtRowNumSet1 = formatter.formatCellValue(row.getCell(j + 4));
					String stxtIntStatusCodeSet1 = row.getCell(j + 5).getStringCellValue();
					String stxtIntNumSet1 = row.getCell(j + 6).getStringCellValue();
					String stxtConsumptionSet1 = formatter.formatCellValue(row.getCell(j + 7));
					int sitxtRowNumSet1 = Integer.parseInt(itxtRowNumSet1);
					String itxtRowNumSet2 = formatter.formatCellValue(row.getCell(j + 8));
					String stxtIntStatusCodeSet2 = row.getCell(j + 9).getStringCellValue();
					String stxtIntNumSet2 = row.getCell(j + 10).getStringCellValue();
					String stxtConsumptionSet2 = formatter.formatCellValue(row.getCell(j + 11));

					String stxtfCmepFileProd = txtfCmepFileProd.getText();
					String stxtfOutputFiles = txtfOutputFiles.getText();

					String OutputFile = stxtfOutputFiles + "TestCase" + itxtTestCaseNum + "_" + "TestConfig"
							+ itxtTestConfigNum + "_" + i + ".csv";
					CsvWriterSettings writersettings = new CsvWriterSettings();
					CsvWriter writer;
					writer = new CsvWriter(new FileWriter(OutputFile), new CsvWriterSettings());

					CsvParserSettings settings = new CsvParserSettings();
					settings.setHeaders("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
					settings.setHeaderExtractionEnabled(true);

					CsvSearch search = new CsvSearch("6", stxtfMeterNumber); // Check
					settings.setProcessor(search);

					CsvParser parser = new CsvParser(settings);
					parser.parse(new File(stxtfCmepFileProd));
					List<String[]> results = search.getRows();
					System.out.println("Rows matched : " + results.size());
					int size = results.size();
					if (size > 0) {
						System.out.println(stxtfMeterNumber);
						writer.writeStringRows(results);
					}
					writer.close();

					// Update and Save

					File sOutputFile = new File(OutputFile);

					String[] numbers1 = stxtIntNumSet1.split(",");
					// String[] numbers3 = stxtIntNumSet3.split(",");
					List<Integer> result = new ArrayList<Integer>();

					int stxtfPosition1;
					for (String number : numbers1) {
						stxtfPosition1 = Integer.parseInt(number.trim());

						switch (stxtfPosition1) {
						case 1:
							stxtfPosition1 = stxtfPosition1 + 14;
							break;
						case 2:
							stxtfPosition1 = stxtfPosition1 + 16;
							break;
						case 3:
							stxtfPosition1 = stxtfPosition1 + 18;
							break;
						case 4:
							stxtfPosition1 = stxtfPosition1 + 20;
							break;
						case 5:
							stxtfPosition1 = stxtfPosition1 + 22;
							break;
						case 6:
							stxtfPosition1 = stxtfPosition1 + 24;
							break;
						case 7:
							stxtfPosition1 = stxtfPosition1 + 26;
							break;
						case 8:
							stxtfPosition1 = stxtfPosition1 + 28;
							break;
						case 9:
							stxtfPosition1 = stxtfPosition1 + 30;
							break;
						case 10:
							stxtfPosition1 = stxtfPosition1 + 32;
							break;
						case 11:
							stxtfPosition1 = stxtfPosition1 + 34;
							break;
						case 12:
							stxtfPosition1 = stxtfPosition1 + 36;
							break;
						case 13:
							stxtfPosition1 = stxtfPosition1 + 38;
							break;
						case 14:
							stxtfPosition1 = stxtfPosition1 + 40;
							break;
						case 15:
							stxtfPosition1 = stxtfPosition1 + 42;
							break;
						case 16:
							stxtfPosition1 = stxtfPosition1 + 44;
							break;
						case 17:
							stxtfPosition1 = stxtfPosition1 + 46;
							break;
						case 18:
							stxtfPosition1 = stxtfPosition1 + 48;
							break;
						case 19:
							stxtfPosition1 = stxtfPosition1 + 50;
							break;
						case 20:
							stxtfPosition1 = stxtfPosition1 + 52;
							break;
						case 21:
							stxtfPosition1 = stxtfPosition1 + 54;
							break;
						case 22:
							stxtfPosition1 = stxtfPosition1 + 56;
							break;
						case 23:
							stxtfPosition1 = stxtfPosition1 + 58;
							break;
						case 24:
							stxtfPosition1 = stxtfPosition1 + 60;
							break;
						case 25:
							stxtfPosition1 = stxtfPosition1 + 62;
							break;
						case 26:
							stxtfPosition1 = stxtfPosition1 + 64;
							break;
						case 27:
							stxtfPosition1 = stxtfPosition1 + 66;
							break;
						case 28:
							stxtfPosition1 = stxtfPosition1 + 68;
							break;
						case 29:
							stxtfPosition1 = stxtfPosition1 + 70;
							break;
						case 30:
							stxtfPosition1 = stxtfPosition1 + 72;
							break;
						case 31:
							stxtfPosition1 = stxtfPosition1 + 74;
							break;
						case 32:
							stxtfPosition1 = stxtfPosition1 + 76;
							break;
						case 33:
							stxtfPosition1 = stxtfPosition1 + 78;
							break;
						case 34:
							stxtfPosition1 = stxtfPosition1 + 80;
							break;
						case 35:
							stxtfPosition1 = stxtfPosition1 + 82;
							break;
						case 36:
							stxtfPosition1 = stxtfPosition1 + 84;
							break;
						case 37:
							stxtfPosition1 = stxtfPosition1 + 86;
							break;
						case 38:
							stxtfPosition1 = stxtfPosition1 + 88;
							break;
						case 39:
							stxtfPosition1 = stxtfPosition1 + 90;
							break;
						case 40:
							stxtfPosition1 = stxtfPosition1 + 92;
							break;
						case 41:
							stxtfPosition1 = stxtfPosition1 + 94;
							break;
						case 42:
							stxtfPosition1 = stxtfPosition1 + 96;
							break;
						case 43:
							stxtfPosition1 = stxtfPosition1 + 98;
							break;
						case 44:
							stxtfPosition1 = stxtfPosition1 + 100;
							break;
						case 45:
							stxtfPosition1 = stxtfPosition1 + 102;
							break;
						case 46:
							stxtfPosition1 = stxtfPosition1 + 104;
							break;
						case 47:
							stxtfPosition1 = stxtfPosition1 + 106;
							break;
						case 48:
							stxtfPosition1 = stxtfPosition1 + 108;
							break;
						default:
							stxtfPosition1 = 0;
						}

						int stxtfPosition1Cst = stxtfPosition1 + 1;

						CSVReader reader;
						try {
							reader = new CSVReader(new FileReader(sOutputFile), ',');
							List<String[]> csvBody = reader.readAll();
							// get CSV row column and replace with by using row and column

							if (stxtConsumptionSet1 == "") {

								csvBody.get(sitxtRowNumSet1)[stxtfPosition1] = stxtIntStatusCodeSet1;
							} else {
								csvBody.get(sitxtRowNumSet1)[stxtfPosition1] = stxtIntStatusCodeSet1;
								csvBody.get(sitxtRowNumSet1)[stxtfPosition1Cst] = stxtConsumptionSet1;
							}

							CSVWriter writer1 = new CSVWriter(new FileWriter(sOutputFile), ',',
									CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER);
							writer1.writeAll(csvBody);
							writer1.flush();
							writer1.close();

							if (stxtIntNumSet2 != "") {
								int stxtfPosition2;
								int sitxtRowNumSet2 = Integer.parseInt(itxtRowNumSet2);
								String[] numbers2 = stxtIntNumSet2.split(",");
								for (String number2 : numbers2) {
									stxtfPosition2 = Integer.parseInt(number2.trim());

									switch (stxtfPosition2) {
									case 1:
										stxtfPosition2 = stxtfPosition2 + 14;
										break;
									case 2:
										stxtfPosition2 = stxtfPosition2 + 16;
										break;
									case 3:
										stxtfPosition2 = stxtfPosition2 + 18;
										break;
									case 4:
										stxtfPosition2 = stxtfPosition2 + 20;
										break;
									case 5:
										stxtfPosition2 = stxtfPosition2 + 22;
										break;
									case 6:
										stxtfPosition2 = stxtfPosition2 + 24;
										break;
									case 7:
										stxtfPosition2 = stxtfPosition2 + 26;
										break;
									case 8:
										stxtfPosition2 = stxtfPosition2 + 28;
										break;
									case 9:
										stxtfPosition2 = stxtfPosition2 + 30;
										break;
									case 10:
										stxtfPosition2 = stxtfPosition2 + 32;
										break;
									case 11:
										stxtfPosition2 = stxtfPosition2 + 34;
										break;
									case 12:
										stxtfPosition2 = stxtfPosition2 + 36;
										break;
									case 13:
										stxtfPosition2 = stxtfPosition2 + 38;
										break;
									case 14:
										stxtfPosition2 = stxtfPosition2 + 40;
										break;
									case 15:
										stxtfPosition2 = stxtfPosition2 + 42;
										break;
									case 16:
										stxtfPosition2 = stxtfPosition2 + 44;
										break;
									case 17:
										stxtfPosition2 = stxtfPosition2 + 46;
										break;
									case 18:
										stxtfPosition2 = stxtfPosition2 + 48;
										break;
									case 19:
										stxtfPosition2 = stxtfPosition2 + 50;
										break;
									case 20:
										stxtfPosition2 = stxtfPosition2 + 52;
										break;
									case 21:
										stxtfPosition2 = stxtfPosition2 + 54;
										break;
									case 22:
										stxtfPosition2 = stxtfPosition2 + 56;
										break;
									case 23:
										stxtfPosition2 = stxtfPosition2 + 58;
										break;
									case 24:
										stxtfPosition2 = stxtfPosition2 + 60;
										break;
									case 25:
										stxtfPosition2 = stxtfPosition2 + 62;
										break;
									case 26:
										stxtfPosition2 = stxtfPosition2 + 64;
										break;
									case 27:
										stxtfPosition2 = stxtfPosition2 + 66;
										break;
									case 28:
										stxtfPosition2 = stxtfPosition2 + 68;
										break;
									case 29:
										stxtfPosition2 = stxtfPosition2 + 70;
										break;
									case 30:
										stxtfPosition2 = stxtfPosition2 + 72;
										break;
									case 31:
										stxtfPosition2 = stxtfPosition2 + 74;
										break;
									case 32:
										stxtfPosition2 = stxtfPosition2 + 76;
										break;
									case 33:
										stxtfPosition2 = stxtfPosition2 + 78;
										break;
									case 34:
										stxtfPosition2 = stxtfPosition2 + 80;
										break;
									case 35:
										stxtfPosition2 = stxtfPosition2 + 82;
										break;
									case 36:
										stxtfPosition2 = stxtfPosition2 + 84;
										break;
									case 37:
										stxtfPosition2 = stxtfPosition2 + 86;
										break;
									case 38:
										stxtfPosition2 = stxtfPosition2 + 88;
										break;
									case 39:
										stxtfPosition2 = stxtfPosition2 + 90;
										break;
									case 40:
										stxtfPosition2 = stxtfPosition2 + 92;
										break;
									case 41:
										stxtfPosition2 = stxtfPosition2 + 94;
										break;
									case 42:
										stxtfPosition2 = stxtfPosition2 + 96;
										break;
									case 43:
										stxtfPosition2 = stxtfPosition2 + 98;
										break;
									case 44:
										stxtfPosition2 = stxtfPosition2 + 100;
										break;
									case 45:
										stxtfPosition2 = stxtfPosition2 + 102;
										break;
									case 46:
										stxtfPosition2 = stxtfPosition2 + 104;
										break;
									case 47:
										stxtfPosition2 = stxtfPosition2 + 106;
										break;
									case 48:
										stxtfPosition2 = stxtfPosition2 + 108;
										break;
									default:
										stxtfPosition2 = 0;
									}

									int stxtfPosition2Cst = stxtfPosition2 + 1;
									// Read existing file
									reader = new CSVReader(new FileReader(sOutputFile), ',');
									// get CSV row column and replace with by using row and column
									if (stxtConsumptionSet1 == "") {
										csvBody.get(sitxtRowNumSet2)[stxtfPosition2] = stxtIntStatusCodeSet2;
									} else {
										csvBody.get(sitxtRowNumSet2)[stxtfPosition2] = stxtIntStatusCodeSet2;
										csvBody.get(sitxtRowNumSet2)[stxtfPosition2Cst] = stxtConsumptionSet2;
									}
									reader.close();
									// Write to CSV file which is open
									CSVWriter writer2 = new CSVWriter(new FileWriter(sOutputFile), ',',
											CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER);
									writer2.writeAll(csvBody);
									writer2.flush();
									writer2.close();
									workbook.close();
								}
							}
						} catch (FileNotFoundException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
					}
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
		if (ae.getSource() == btnClear) {
			txtfCmepFileProd.setText(null);
			txtfTestdataInputSheet.setText(null);
			txtfOutputFiles.setText(null);
		}

		if (ae.getSource() == btnExit) {
			System.exit(0);
		}

		System.out.println("Completed");
		txtfCmepFileProd.setText(null);
		txtfTestdataInputSheet.setText(null);
		txtfOutputFiles.setText(null);
		System.exit(0);
	}
}