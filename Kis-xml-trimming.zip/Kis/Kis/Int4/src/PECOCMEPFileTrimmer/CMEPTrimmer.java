package PECOCMEPFileTrimmer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class CMEPTrimmer {
	
	private static DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	private static DocumentBuilder dBuilder = null;
	
	static {
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			System.out.println("Exception in creating Document Builder : " + e);
			e.printStackTrace();
		}
	}

	public void main(String MeterPath, String CMEPProd, String CMEPTrimmed) throws Exception {
		
		File fileMeterNumbers = new File(MeterPath);
		List<String> lstMeterNumbers = loadMeterNumberList(fileMeterNumbers);

		long start = System.currentTimeMillis();
		System.out.println("Start time ........ : " + start);
		File folder = new File(CMEPProd);
		File[] listOfFiles = folder.listFiles();
		int intRecoundCount = 1;
		Document docInputFile = null;
		Document docOutputFile = null;
		Element docOutputElement = null;
		for(int i = 0; i < listOfFiles.length; i++){
			String filename = listOfFiles[i].getName();
			if(filename.endsWith(".xml")||filename.endsWith(".XML"))
			{
				System.out.println("Reading File " + filename + " :");
				docInputFile = dBuilder.parse(new File(CMEPProd + "\\" + filename));
				Element docInputEle = docInputFile.getDocumentElement();
				NodeList ndlMeterData = docInputFile.getElementsByTagName("MeterData");
				int inMeterLength = ndlMeterData.getLength();
				Element eleMeterData = null;
				
				for (int a = 0; a < inMeterLength; a++) {

					if((i == 0 && null == docOutputFile) || intRecoundCount == 451) {
						docOutputFile = dBuilder.newDocument();
						docOutputElement = docOutputFile.createElement("SSNExportDocument");
						copyAttributes(docOutputElement, docInputEle);
						docOutputFile.appendChild(docOutputElement);
						intRecoundCount = 1;
					}

					eleMeterData = (Element)ndlMeterData.item(a);
					if(lstMeterNumbers.contains(eleMeterData.getAttribute("MeterName"))) {
						docOutputElement.appendChild(docOutputFile.importNode(eleMeterData, true));
						if(intRecoundCount == 450) {
							writeDocumentToFile(CMEPTrimmed + "_" + System.currentTimeMillis() + ".xml", docOutputFile);
						}
						intRecoundCount++;
					}
				}				
			}
		}
		
		if (intRecoundCount < 450) {
			writeDocumentToFile(CMEPTrimmed + "_" + System.currentTimeMillis() + ".xml", docOutputFile);
		}
		
		System.out.println("End time ........ : " + System.currentTimeMillis());
		System.out.println("Total Time taken ---------- : " + (System.currentTimeMillis() - start)/60000 + " min");
		System.out.println("Completed");
		JOptionPane.showMessageDialog(null, "CMEP File trim is completed ", "PECO CMEP Trimmer Status",
				JOptionPane.INFORMATION_MESSAGE);
		
	}
	
	/**
	 * Method to read the Meter Number List file and load lines to ArrayList.
	 * eg: List<H016999422>
	 * 
	 * @param fileMeterNumbers
	 * @return
	 */
	private List<String> loadMeterNumberList(File fileMeterNumbers) throws IOException{
		List<String> meterNumberLst = new ArrayList<String>();
		FileReader fileReader = new FileReader(fileMeterNumbers);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			meterNumberLst.add(line);
		}
		fileReader.close();

		return meterNumberLst;
	}
	
	private void writeDocumentToFile(String outPutFile, Document inputDocument) throws Exception{
        Transformer tr = TransformerFactory.newInstance().newTransformer();
        tr.setOutputProperty(OutputKeys.INDENT, "yes");
        tr.setOutputProperty(OutputKeys.METHOD, "xml");
//        tr.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
//        tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "roles.dtd");
//        tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        tr.transform(new DOMSource(inputDocument), 
                             new StreamResult(new FileOutputStream(outPutFile)));

	}

	/**
	 * This method is for setting the attribute of an element
	 * 
	 * @param objElement
	 *            Element where this attribute should be set
	 * @param attributeName
	 *            Name of the attribute
	 * @param attributeValue
	 *            Value of the attribute
	 */
	public static void setAttribute(Element objElement, String attributeName, String attributeValue) {
		objElement.setAttribute(attributeName, attributeValue);
	}

	/**
	 * This method will copy all the attribute from one node to other node.
	 * 
	 * @param toEle
	 *            toEle
	 * @param fromEle
	 *            fromEle
	 * 
	 */
	public static void copyAttributes(Element toEle, Element fromEle) {
		NamedNodeMap fromAttrbMap = fromEle.getAttributes();

		if (fromAttrbMap != null) {
			int fromAttrbMapLength = fromAttrbMap.getLength();

			for (int i = 0; i < fromAttrbMapLength; i++) {
				Node attrbNode = fromAttrbMap.item(i);

				if ((attrbNode == null) || (attrbNode.getNodeType() != Node.ATTRIBUTE_NODE)) {
					continue;
				}

				String attrbName = attrbNode.getNodeName();
				String attrbVal = attrbNode.getNodeValue();

				String toAttrbVal = toEle.getAttribute(attrbName);

				if (toAttrbVal.length() == 0) {
					setAttribute(toEle, attrbName, attrbVal);
				}
			}
		}
	}

};