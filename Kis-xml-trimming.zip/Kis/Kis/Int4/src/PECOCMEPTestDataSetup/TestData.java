package PECOCMEPTestDataSetup;

import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.Toolkit;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.univocity.parsers.common.ParsingContext;
import com.univocity.parsers.common.processor.RowListProcessor;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

import PECOCMEPFileTrimmer.CMEPFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;


public class TestData extends JFrame implements ActionListener {
JFrame frmPecoRniTest;
JTextField txtfCmepFilePath, txtfTestDataSheetPath, txtfMeterNumber, txtfPosition, txtfConsumptionValue;
JButton btnExtractData, btnUpdate, btnClear, btnExit;
JLabel txtCmpFilePath, txtTestDataSheetPath,txtMeterNumber, txtIntervalStatusCode, txtRow, txtPosition, txtCosumptionValue, txtIntervalSize;
JComboBox cbIntervalStatusCode, cbIntervalSize, cbRow;
private JTextField txtPecoRniTest;


	public static void main(String[] args) throws IOException{
		TestData td = new TestData();
		td.frmPecoRniTest.setVisible(true);
	}

	/*** Initialize the contents of the frame ***/
	TestData() {
		frmPecoRniTest = new JFrame("PECO RNI Test data Setup tool");
		frmPecoRniTest.setIconImage(Toolkit.getDefaultToolkit().getImage(TestData.class.getResource("/com/sun/javafx/scene/control/skin/modena/HTMLEditor-Numbered-Black-rtl.png")));
		frmPecoRniTest.setBounds(100, 100, 800, 500);
		frmPecoRniTest.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPecoRniTest.getContentPane().setLayout(null);
		
		txtCmpFilePath = new JLabel();
		txtCmpFilePath.setBounds(10, 63, 164, 20);
		txtCmpFilePath.setForeground(new Color(0, 0, 0));
		txtCmpFilePath.setText("CMEP Production File Path");
		frmPecoRniTest.getContentPane().add(txtCmpFilePath);
		
		txtfCmepFilePath = new JTextField();
		txtfCmepFilePath.setBounds(186, 63, 345, 20);
		frmPecoRniTest.getContentPane().add(txtfCmepFilePath);
		txtfCmepFilePath.setColumns(10);
		
		txtTestDataSheetPath = new JLabel();
		txtTestDataSheetPath.setBounds(10, 127, 164, 20);
		txtTestDataSheetPath.setText("Test data sheet path");
		frmPecoRniTest.getContentPane().add(txtTestDataSheetPath);
		
		txtfTestDataSheetPath = new JTextField();
		txtfTestDataSheetPath.setBounds(186, 127, 345, 20);
		txtfTestDataSheetPath.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfTestDataSheetPath);
		
		txtMeterNumber = new JLabel();
		txtMeterNumber.setBounds(10, 95, 164, 20);
		txtMeterNumber.setText("Meter Number");
		frmPecoRniTest.getContentPane().add(txtMeterNumber);
		
		txtfMeterNumber = new JTextField();
		txtfMeterNumber.setBounds(186, 95, 345, 20);
		txtfMeterNumber.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfMeterNumber);
		
		txtIntervalStatusCode = new JLabel();
		txtIntervalStatusCode.setBounds(10, 219, 115, 20);
		txtIntervalStatusCode.setText("Interval Status code");
		frmPecoRniTest.getContentPane().add(txtIntervalStatusCode);
		
		txtRow = new JLabel();
		txtRow.setBounds(10, 283, 65, 20);
		txtRow.setText("Row #");
		frmPecoRniTest.getContentPane().add(txtRow);
		/*
		cbRow = new JTextField();
		cbRow.setBounds(142, 283, 81, 20);
		cbRow.setColumns(10);
		frmPecoRniTest.getContentPane().add(cbRow);
		*/
		
		cbRow = new JComboBox();
		cbRow.setModel(new DefaultComboBoxModel(new String[] {"", "1", "2"}));
		cbRow.setToolTipText("");
		cbRow.setMaximumRowCount(70);
		cbRow.setBounds(142, 283, 81, 20);
		frmPecoRniTest.getContentPane().add(cbRow);
		
		txtPosition = new JLabel();
		txtPosition.setBounds(10, 312, 65, 20);
		txtPosition.setText("Interval #");
		frmPecoRniTest.getContentPane().add(txtPosition);
		
		txtfPosition = new JTextField();
		txtfPosition.setBounds(142, 312, 81, 20);
		txtfPosition.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfPosition);
		
		txtCosumptionValue = new JLabel();
		txtCosumptionValue.setBounds(10, 344, 115, 20);
		txtCosumptionValue.setText("Cosumption Value");
		frmPecoRniTest.getContentPane().add(txtCosumptionValue);
		
		txtfConsumptionValue = new JTextField();
		txtfConsumptionValue.setBounds(142, 344, 43, 20);
		txtfConsumptionValue.setColumns(10);
		frmPecoRniTest.getContentPane().add(txtfConsumptionValue);
		
		txtIntervalSize = new JLabel();
		txtIntervalSize.setBounds(10, 251, 109, 20);
		txtIntervalSize.setText("Interval Size");
		frmPecoRniTest.getContentPane().add(txtIntervalSize);
		
		cbIntervalStatusCode = new JComboBox();
		cbIntervalStatusCode.setBounds(142, 219, 81, 20);
		cbIntervalStatusCode.setModel(new DefaultComboBoxModel(new String[] {"","N289", "N32", "N33", "N33057", "N33059", "N34", "N35", "N36", "N38", "N39", "N41", "N43", "N49", "N51", "N55", "N59", "R0", "R1", "R10", "R1024", "R1026", "R1028", "R1030", "R1032", "R1040", "R1046", "R1280", "R1282", "R1286", "R1290", "R1294", "R1298", "R1302", "R1306", "R1310", "R14", "R16", "R18", "R2", "R2048", "R2050", "R2052", "R2054", "R2056", "R2058", "R2062", "R2064", "R2066", "R2070", "R2074", "R2078", "R24", "R256", "R26", "R262", "R264", "R266", "R272", "R280", "R33", "R33024", "R33028", "R33032", "R33040", "R33048", "R34048", "R34050", "R34054", "R4", "R512", "R6", "R8"}));
		cbIntervalStatusCode.setMaximumRowCount(70);
		frmPecoRniTest.getContentPane().add(cbIntervalStatusCode);
			
		cbIntervalSize = new JComboBox();
		cbIntervalSize.setBounds(142, 251, 81, 20);
		cbIntervalSize.setModel(new DefaultComboBoxModel(new String[] {"","15 mins", "60 mins"}));
		cbIntervalSize.setToolTipText("");
		cbIntervalSize.setMaximumRowCount(70);
		frmPecoRniTest.getContentPane().add(cbIntervalSize);
		
		
		btnExtractData = new JButton("Extract data");
		btnExtractData.setBounds(12, 170, 122, 23);
		frmPecoRniTest.getContentPane().add(btnExtractData);
		
		btnUpdate = new JButton("Update and Save");
		btnUpdate.setBounds(12, 394, 142, 23);
		frmPecoRniTest.getContentPane().add(btnUpdate);
		
		btnClear = new JButton("Clear");
		btnClear.setBounds(218, 394, 142, 23);
		frmPecoRniTest.getContentPane().add(btnClear);
		
		btnExit = new JButton("Exit");
		btnExit.setBounds(403, 394, 142, 23);
		frmPecoRniTest.getContentPane().add(btnExit);
		

		txtPecoRniTest = new JTextField();
		txtPecoRniTest.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtPecoRniTest.setForeground(new Color(255, 255, 255));
		txtPecoRniTest.setBackground(new Color(51, 153, 255));
		txtPecoRniTest.setHorizontalAlignment(SwingConstants.CENTER);
		txtPecoRniTest.setText("PECO RNI Test data set up Tool - Interval Status codes");
		txtPecoRniTest.setBounds(0, 0, 784, 39);
		frmPecoRniTest.getContentPane().add(txtPecoRniTest);
		txtPecoRniTest.setColumns(10);
		//frmPecoRniTest.getContentPane().setFocusTraversalPolicy(new FocusTraversalPolicy(new Component[]{txtCmpFilePath, txtfCmepFilePath, txtTestDataSheetPath, txtfTestDataSheetPath, txtMeterNumber, txtfMeterNumber, btnExtractData, txtIntervalStatusCode, txtRow, cbRow, txtPosition, txtfPosition, btnUpdate, txtCosumptionValue, txtfConsumptionValue, cbIntervalStatusCode, txtIntervalSize, cbIntervalSize}));

		
		//add Action Listener to the buttons
		btnExtractData.addActionListener(this);
		btnUpdate.addActionListener(this);
		btnClear.addActionListener(this);
		btnExit.addActionListener(this);
		

	}


	public void actionPerformed(ActionEvent ae){
		
	if (ae.getSource()== btnExtractData)
	{
		String stxtCmpFilePath = txtfCmepFilePath.getText(); 
		String stxtfMeterNumber = txtfMeterNumber.getText();
		String stxtfTestDataSheetPath = txtfTestDataSheetPath.getText()+stxtfMeterNumber+"_Updated.csv";
		
		CsvWriterSettings writersettings = new CsvWriterSettings();
		CsvWriter writer = null;
		try {
			writer = new CsvWriter(new FileWriter(stxtfTestDataSheetPath), new CsvWriterSettings());
		} catch (IOException e) {
			e.printStackTrace();
		}
		CsvParserSettings settings = new CsvParserSettings();
		settings.setHeaders("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
		settings.setHeaderExtractionEnabled(true);
		CsvSearch search = new CsvSearch("6", stxtfMeterNumber); 
		// We instruct the parser to send all rows parsed to your custom RowProcessor.
		settings.setProcessor(search);
		// Finally, we create a parser
		CsvParser parser = new CsvParser(settings);
		parser.parse(new File(stxtCmpFilePath));
		List<String[]> results = search.getRows();
		System.out.println("Rows matched : " + results.size());

		int size = results.size();
		if (size > 0) {
			System.out.println(stxtfMeterNumber);
			writer.writeStringRows(results);
		}
		writer.close();
		if (size == 2) {
			cbIntervalSize.setSelectedItem("60 mins");
			cbIntervalSize.disable();
			cbRow.setSelectedItem("1");
			cbRow.disable();
		}
		else if (size == 3){
			cbIntervalSize.setSelectedItem("15 mins");
			
		}
	}	
	
	if (ae.getSource()== btnUpdate)
	{
		String stxtCmpFilePath = txtfCmepFilePath.getText();
		String stxtfMeterNumber = txtfMeterNumber.getText();
		String stxtfTestDataSheetPath = txtfTestDataSheetPath.getText()+stxtfMeterNumber+"_Updated.csv";
		int scbRow = Integer.parseInt((String) cbRow.getSelectedItem());
		String strtxtfPosition = txtfPosition.getText();
		String stxtfConsumptionValue = txtfConsumptionValue.getText();
		String scbIntervalStatusCode = (String) cbIntervalStatusCode.getSelectedItem();
		String scbIntervalSize = (String) cbIntervalSize.getSelectedItem();
		
		File inputFile = new File(stxtfTestDataSheetPath);
		
		
		String[] numbers = strtxtfPosition.split(",");
		List<Integer> result = new ArrayList<Integer>();
	
		int stxtfPosition;
		for(String number : numbers) {
			stxtfPosition= Integer.parseInt(number.trim());
		    
		switch(stxtfPosition)
		{
		case 1:
			stxtfPosition = stxtfPosition+14;
		break;
		case 2:
			stxtfPosition = stxtfPosition+16;
		break;
		case 3:
			stxtfPosition = stxtfPosition+18;
		break;
		case 4:
			stxtfPosition = stxtfPosition+20;
		break;
		case 5:
			stxtfPosition = stxtfPosition+22;
		break;
		case 6:
			stxtfPosition = stxtfPosition+24;
		break;
		case 7:
			stxtfPosition = stxtfPosition+26;
		break;
		case 8:
			stxtfPosition = stxtfPosition+28;
		break;
		case 9:
			stxtfPosition = stxtfPosition+30;
		break;
		case 10:
			stxtfPosition = stxtfPosition+32;
		break;
		case 11:
			stxtfPosition = stxtfPosition+34;
		break;
		case 12:
			stxtfPosition = stxtfPosition+36;
		break;
		case 13:
			stxtfPosition = stxtfPosition+38;
		break;
		case 14:
			stxtfPosition = stxtfPosition+40;
		break;
		case 15:
			stxtfPosition = stxtfPosition+42;
		break;
		case 16:
			stxtfPosition = stxtfPosition+44;
		break;
		case 17:
			stxtfPosition = stxtfPosition+46;
		break;
		case 18:
			stxtfPosition = stxtfPosition+48;
		break;
		case 19:
			stxtfPosition = stxtfPosition+50;
		break;
		case 20:
			stxtfPosition = stxtfPosition+52;
		break;
		case 21:
			stxtfPosition = stxtfPosition+54;
		break;
		case 22:
			stxtfPosition = stxtfPosition+56;
		break;
		case 23:
			stxtfPosition = stxtfPosition+58;
		break;
		case 24:
			stxtfPosition = stxtfPosition+60;
		break;
		case 25:
			stxtfPosition = stxtfPosition+62;
		break;
		case 26:
			stxtfPosition = stxtfPosition+64;
		break;
		case 27:
			stxtfPosition = stxtfPosition+66;
		break;
		case 28:
			stxtfPosition = stxtfPosition+68;
		break;
		case 29:
			stxtfPosition = stxtfPosition+70;
		break;
		case 30:
			stxtfPosition = stxtfPosition+72;
		break;
		case 31:
			stxtfPosition = stxtfPosition+74;
		break;
		case 32:
			stxtfPosition = stxtfPosition+76;
		break;
		case 33:
			stxtfPosition = stxtfPosition+78;
		break;
		case 34:
			stxtfPosition = stxtfPosition+80;
		break;
		case 35:
			stxtfPosition = stxtfPosition+82;
		break;
		case 36:
			stxtfPosition = stxtfPosition+84;
		break;
		case 37:
			stxtfPosition = stxtfPosition+86;
		break;
		case 38:
			stxtfPosition = stxtfPosition+88;
		break;
		case 39:
			stxtfPosition = stxtfPosition+90;
		break;
		case 40:
			stxtfPosition = stxtfPosition+92;
		break;
		case 41:
			stxtfPosition = stxtfPosition+94;
		break;
		case 42:
			stxtfPosition = stxtfPosition+96;
		break;
		case 43:
			stxtfPosition = stxtfPosition+98;
		break;
		case 44:
			stxtfPosition = stxtfPosition+100;
		break;
		case 45:
			stxtfPosition = stxtfPosition+102;
		break;
		case 46:
			stxtfPosition = stxtfPosition+104;
		break;
		case 47:
			stxtfPosition = stxtfPosition+106;
		break;
		case 48:
			stxtfPosition = stxtfPosition+108;
		break;
		default :
			stxtfPosition = 0;
		}
		
		
		int stxtfPositionCst = stxtfPosition+1;

		// Read existing file 
		CSVReader reader;
		try {
		reader = new CSVReader(new FileReader(stxtfTestDataSheetPath), ',');
		List<String[]> csvBody = reader.readAll();
		// get CSV row column  and replace with by using row and column

			
			    if (stxtfConsumptionValue == "") {
			    	csvBody.get(scbRow)[stxtfPosition] = scbIntervalStatusCode;
			    } else {
			    	csvBody.get(scbRow)[stxtfPosition] = scbIntervalStatusCode;
					csvBody.get(scbRow)[stxtfPositionCst] = stxtfConsumptionValue; 
			    } 
				
				
		reader.close();
		// Write to CSV file which is open
		CSVWriter writer = new CSVWriter(new FileWriter(inputFile), ',', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER);
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		System.out.println("Completed");
		JOptionPane.showMessageDialog(null, "Test Data setup on the meter is completed ", "Test Data setup status",
				JOptionPane.INFORMATION_MESSAGE);
	
	}
	
	if (ae.getSource()== btnClear)
	{
		txtfCmepFilePath.setText(null);
		txtfTestDataSheetPath.setText(null);
		txtfMeterNumber.setText(null);
		cbRow.setSelectedItem(null);
		txtfPosition.setText(null);
		txtfConsumptionValue.setText(null);
		cbIntervalStatusCode.setSelectedIndex(0);
		cbIntervalSize.setSelectedIndex(0);
	}
	
	if (ae.getSource() == btnExit)
	{
		System.exit(0);
	}
	}
		
	
	
	private void If(boolean b) {
		// TODO Auto-generated method stub
		
	}


	static class CsvSearch extends RowListProcessor {
		private final String stringToMatch;
		private final String columnToMatch;
		private int indexToMatch = -1;

		public CsvSearch(String columnToMatch, String stringToMatch) {
			this.columnToMatch = columnToMatch;
			this.stringToMatch = stringToMatch.toLowerCase();
		}

		public CsvSearch(int columnToMatch, String stringToMatch) {
			this(stringToMatch, null);
			indexToMatch = columnToMatch;
		}

		public void rowProcessed(String[] row, ParsingContext context) {
			if (indexToMatch == -1) {
				indexToMatch = context.indexOf(columnToMatch);
			}

			String value = row[indexToMatch];
			if (value != null && value.toLowerCase().contains(stringToMatch)) {
				super.rowProcessed(row, context);
			}
			// else skip the row.
		}
	}
}
